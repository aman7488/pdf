package com.microservice.goldcustody;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoldcustodyApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoldcustodyApplication.class, args);
	}

}
