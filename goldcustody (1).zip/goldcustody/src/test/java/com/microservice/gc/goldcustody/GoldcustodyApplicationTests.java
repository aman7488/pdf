package com.microservice.gc.goldcustody;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoldcustodyApplicationTests {

	@Test
	void contextLoads() {
	}

}
